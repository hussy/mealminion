var express = require("express");
var router = express.Router();
const mysql = require("../../../controllers/mysqlCluster.js");
var passport = require("passport");

router.post('/login-submit', (req, res, next) => {
    
    console.log(req);
});
 
passport.serializeUser(function(userName, done) {
    done(null, userName);
});
  
  passport.deserializeUser(function(userName, done) {
    done(null, userName);
});

module.exports = router;

