const mysql = require("../../../controllers/mysqlCluster.js");
const commonFunctions = require("../../../commonFunction.js");

function addRestaurant(data,session){
    return new Promise((resolve) => {
        var user_id = session.passport.user;
        var entryData = [];
        entryData["restaurant_name"] = data.restaurant_name;
        entryData['restaurant_information'] = {
            owner_name: data.owner_name,
            owner_contact_number: data.owner_contact_number,
            owner_cnic_number: data.owner_cnic_number,
            owner_address: data.owner_address,
            business_identification_number: data.business_identification_number,
            hq_country: data.hq_country,
            hq_city: data.hq_city,
            hq_address: data.hq_address,
            hq_primary_currency: data.hq_primary_currency,

        };
        var sync_id = "";
        commonFunctions.insertInfo(user_id)
        .then(function(result){
            entryData["sync_id"] = result.sync_id;
            entryData["history"] = result.history;
            entryData["sync_devices"] = result.sync_devices;
            mysql.MainDBqueryInsert("tb_restaurants", entryData)
            .then(function(result){
                resolve(JSON.stringify(result));
            })
            .catch(function(error){
                commonFunctions.errorLogger(error);
            });
        })
        .catch(function(error){
            commonFunctions.errorLogger(error);
        })
    });
}
// branch submit
function addBranch(data,session){
    return new Promise((resolve) => {
        function addBranch(){
            return new Promise((resolve) => {
                var user_id = session.passport.user;
                var restaurant_id = session.restaurant_id;
                var entryData = [];
                entryData["restaurant_id"] = restaurant_id;
                entryData["master_pin"] = data.master_pin;
                entryData["logout_cash_compesate_range"] = data.logout_cash_compesate_range;
                entryData['branch_information'] = {
                    branch_name: data.branch_name,
                    contact_person_name: data.contact_person_name,
                    branch_number: data.branch_number,
                    country_id: data.country_id,
                    state: data.state,
                    city: data.city,
                    currency_id: data.currency_id,
                    address: data.address,
                };
                commonFunctions.insertInfo(user_id)
                .then(function(result){
                    entryData["sync_id"] = result.sync_id;
                    entryData["history"] = result.history;
                    entryData["sync_devices"] = result.sync_devices;
                    mysql.MainDBqueryInsert("tb_branches", entryData)
                    .then(function(result){
                        resolve(JSON.stringify(result));
                    })
                    .catch(function(error){
                        throw new Error(error);
                    });
                })
                .catch(function(error){
                    throw new Error(error);
                })
            });
        }
        mysql.MainDBquerySelect("tb_branches","", "*")
        .then(function(response){
            if(response.status == "1"){
                var branches = response.results; 
                if(branches.length > 0){
                    for(var i = 0; i < branches.length; i++){
                        var branch_information = JSON.parse(branches[i].branch_information);
                        if(branch_information.branch_name == data.branch_name){
                            throw new Error("Branch Exists");
                        } else {
                            addBranch()
                            .then(function (response){
                                resolve(response);
                            })
                            .catch(function (error){
                                resolve(error);
                            })
                        }
                    }
                } else {
                    addBranch()
                    .then(function (response){
                        resolve(response);
                    })
                    .catch(function (error){
                        resolve(error);
                    })
                }
            } else {
                throw new Error(response.error);
            }
        })
        .catch(function (error){
            console.log(error);
            var errorMessage = JSON.stringify({
                title: "Error",
                icon: "error",
                text: error.message
            });
            commonFunctions.errorLogger(error.message);
            resolve(errorMessage);
        })
    });
}
function branch_edit(data,session){
    return new Promise((resolve) => {

        function editBranch(){
            return new Promise((resolve) => {
                var user_id = session.passport.user;
                var restaurant_id = session.restaurant_id;
                var entryData = [];
                entryData["restaurant_id"] = restaurant_id;
                entryData["master_pin"] = data.master_pin_edit;
                entryData["logout_cash_compesate_range"] = data.logout_cash_compesate_range_edit;
                entryData['branch_information'] = {
                    branch_name: data.branch_name_edit,
                    contact_person_name: data.contact_person_name_edit,
                    branch_number: data.branch_number_edit,
                    country_id: data.country_id_edit,
                    state: data.state_edit,
                    city: data.city_edit,
                    currency_id: data.currency_id_edit,
                    address: data.address_edit,
                };
                commonFunctions.updateInfo(user_id, "tb_branches", data.sync_id_edit, entryData)
                .then(function(result){
                    resolve(JSON.stringify(result));
                    entryData["history"] = result.history;
                    entryData["sync_devices"] = result.sync_devices;
                    var whereQuery = {
                        sync_id: data.sync_id_edit
                    }
                    
                    mysql.MainDBqueryUpdate("tb_branches", entryData,whereQuery)
                    .then(function(result){
                        resolve(JSON.stringify(result));
                    })
                    .catch(function(error){
                        throw new Error(error);
                    });
                })
                .catch(function(error){
                    throw new Error(error);
                })
            });
        }

        mysql.MainDBquerySelect("tb_branches","where sync_id !='"+data.sync_id_edit+"'", "*")
        .then(function(response){
            if(response.status == "1"){
                var branches = response.results; 
                console.log(branches.length)
                if(branches.length > 0){
                    for(var i = 0; i < branches.length; i++){
                        var branch_information = JSON.parse(branches[i].branch_information);
                        if(branch_information.branch_name == data.branch_name_edit){
                            console.log("HEE")
                            throw new Error("Branch Exists");
                        } else {
                            editBranch()
                                .then(function (response){
                                    resolve(response);
                                })
                                .catch(function (error){
                                    resolve(error);
                                })
                        }
                    }
                } else {
                    editBranch()
                        .then(function (response){
                            resolve(response);
                        })
                        .catch(function (error){
                            resolve(error);
                        })
                }
            } else {
                throw new Error(response.error);
            }
        })
        .catch(function (error){
            var errorMessage = JSON.stringify({
                title: "Error",
                icon: "error",
                text: error.message
            });
            commonFunctions.errorLogger(error.message);
            resolve(errorMessage);
        })
    });
}
function getBranchesData(){
    return new Promise((resolve,reject) => {
        mysql.MainDBquerySelect("tb_branches","","*")
        .then(function(result){
            if(result.status == "1"){
                resolve(JSON.stringify(result.results));
            } else {
                reject(result.error);
            }
        })
        .catch(function (error){
            reject(error);
        });
    });
}
function editBranchInfo(req){
    return new Promise((resolve,reject) => {
        mysql.MainDBquerySelect("tb_branches","where sync_id = '"+req+"'","*")
        .then(function(result){
            if(result.status == "1"){
                resolve(JSON.stringify(result.results));
            } else {
                reject(result.error);
            }
        })
        .catch(function (error){
            reject(error);
        });
    });
}
function getBranchesInformation(req){
    return new Promise((resolve,reject) => {
        mysql.MainDBquerySelect("tb_branches","where sync_id = '"+req+"'","branch_information")
        .then(function(result){
            if(result.status == "1"){
                var row = result.results[0];
                var branch_information = JSON.parse(row.branch_information)
                var country_id = branch_information.country_id
                var city_id = branch_information.city
                var state_id = branch_information.state
                var currency_id = branch_information.currency_id;
                var dataPromises = [];
                dataPromises.push(mysql.MainDBquerySelect("tb_countries","where id = '"+country_id+"'","name as country_name"))
                dataPromises.push(mysql.MainDBquerySelect("tb_cities","where id = '"+city_id+"'","name as city_name"))
                dataPromises.push(mysql.MainDBquerySelect("tb_states","where id = '"+state_id+"'","name as state_name"))
                dataPromises.push(mysql.MainDBquerySelect("tb_currencies","where id = '"+currency_id+"'","currency_code as currency_code"))

                var dataToReturn = {
                    branch_information: row.branch_information
                };
                Promise.all(dataPromises)
                    .then(function(result){
                        for(var i = 0; i < result.length; i++){
                            for(var key in result[i].results[0]){
                                dataToReturn[key] = result[i].results[0][key]
                            }
                        }
                        console.log(JSON.stringify(dataToReturn));
                        resolve(JSON.stringify(dataToReturn));
                    })
                    .catch(function (error){
                        reject(error);
                    })
            } else {
                reject(result.error);
            }
        })
        .catch(function (error){
            reject(error);
        });
    });
}
module.exports.branch_edit = branch_edit;
module.exports.editBranchInfo = editBranchInfo;
module.exports.getBranchesInformation = getBranchesInformation;
module.exports.getBranchesData = getBranchesData;
module.exports.addBranch = addBranch;
module.exports.addRestaurant = addRestaurant;