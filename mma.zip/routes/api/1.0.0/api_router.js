var express = require("express");
var app = express();
var router = express.Router();
var passport = require("passport");
const mysql = require("../../../controllers/mysqlCluster.js");
var bcrypt = require('bcryptjs');
const commonFunctions = require("../../../commonFunction.js");

const restaurant_add = require("./restaurant_add.js");


var response = {};


router.post('/', (req, res, next) => {
    res.json('NO API COMMAND PROVIDED');
    res.end();
});

router.get('/', (req, res, next) => {
    response['error']	=	'1';
    response['message']	=	'No Command Provided';
    res.end(JSON.stringify(response));
});

// Add restaurant
router.post('/restaurant_add', (req, res, next) => {
    restaurant_add.addRestaurant(req.body,req.session)
    .then(function(result){
        res.end(result);
    })
    .catch(function(error){
        res.end(error);
    });
});
//Add Branch
router.post('/branch_add', (req, res, next) => {
    restaurant_add.addBranch(req.body,req.session)
    .then(function(result){
        res.end(result);
    })
    .catch(function(error){
        res.end(error);
    });
});

router.post('/branch_edit', (req, res, next) => {
    restaurant_add.branch_edit(req.body,req.session)
    .then(function(result){
        res.end(result);
    })
    .catch(function(error){
        res.end(error);
    });
});


router.post('/getCountries', (req, res, next) => {
    commonFunctions.getCountries()
    .then(function(result){
        res.end(result);
    })
    .catch(function(error){
        res.end(error);
    });
});
//Get states
router.post('/getStates', (req, res, next) => {
    commonFunctions.getStates(req.body)
    .then(function(result){
        res.end(result);
    })
    .catch(function(error){
        res.end(error);
    });
});
//Get city
router.post('/getCity', (req, res, next) => {
    commonFunctions.getCity(req.body)
    .then(function(result){
        res.end(result);
    })
    .catch(function(error){
        res.end(error);
    });
});
//Get currencies
router.post('/getCurrencies', (req, res, next) => {
    commonFunctions.getCurrencies()
    .then(function(result){
        res.end(result);
    })
    .catch(function(error){
        res.end(error);
    });
});
// Get branches data
router.post('/getBranchesData', (req, res, next) => {
    restaurant_add.getBranchesData()
    .then(function(result){
        res.end(result);
    })
    .catch(function(error){
        res.end(error);
    });
});
router.post('/getBranchesInformation', (req, res, next) => {
    restaurant_add.getBranchesInformation(req.body.sync_id)
    .then(function(result){
        res.end(result);
    })
    .catch(function(error){
        res.end(error);
    });
});
router.post('/editBranchInfo', (req, res, next) => {
    restaurant_add.editBranchInfo(req.body.sync_id)
    .then(function(result){
        res.end(result);
    })
    .catch(function(error){
        res.end(error);
    });
});

router.get('/testUpdate', (req, res, next) => {
    var newData = {
        restaurant_name: "sfsdfsdf Cafessss",
        restaurant_information: "{hello:\"sfsdfsdfdsfsdf\"}"
    }
    commonFunctions.updateInfo("1","tb_restaurants","6545465468746876854864684684684864648", newData)
        .then(function(result){
            res.end(JSON.stringify(result));
        })
        .catch(function(error){
            res.end("error");
        });
});


router.post('/login-submit', (req, res, next) => {
    var username = req.body.username;
    var password = req.body.pass;

    mysql.MainDBquerySelect("tb_restaurant_staff","where username = '" + username + "'","*")
    .then(function(result){
        if(result.status == "1"){
            if(result.results.length > 0){
                var user_id = result.results[0].sync_id;
                var restaurant_id = result.results[0].restaurant_id;
                bcrypt.compare(password, result.results[0].password, function(err, result) {
                    if(result){
                        mysql.MainDBquerySelect("tb_restaurants","where sync_id = '" + restaurant_id + "'","*")
                        .then(function(result){
                            if(result.status == "1"){
                                req.session.restaurant_id = restaurant_id;
                                req.session.restaurant_name = result.results[0].restaurant_name;
                                req.session.database_name = result.results[0].database_name;
                                req.login(user_id, function (err){
                                    if(err){
                                        response['error']	=	'1';
                                        response['message']	=	'Uknown Error Logging In';
                                        res.json(JSON.stringify(response));
                                    } else {
                                        response['error'] = '0';
                                        response['message'] = 'Logged in Successfully';
                                        res.json(JSON.stringify(response));
                                    }
                                });
                            } else {
                                response['error']	=	'1';
                                response['message']	=	'Uknown Error Logging In';
                                res.json(JSON.stringify(response));
                            }
                        })
                        .catch(function (error){
                            response['error']	=	'1';
                            response['message']	=	'Uknown Error Logging In';
                            res.json(JSON.stringify(response));
                        })
                        
                    } else {
                        response['error']	=	'1';
                        response['message']	=	'Your Username or Password is incorrect';
                        res.json(JSON.stringify(response));
                    }
                });
            } else {
                response['error']	=	'1';
                response['message']	=	'Username does not exist';
                res.json(JSON.stringify(response));
            }
        } else {
            response['error']	=	'1';
            response['message']	=	'Error Logging In';
            res.json(JSON.stringify(response));
        }
    })
    .catch(function(error){
        res.json(JSON.stringify(response));
    })
});

passport.serializeUser(function(user_id, done) {
    done(null, user_id);
});
  
passport.deserializeUser(function(user_id, done) {
    done(null, user_id);
});

module.exports = router;