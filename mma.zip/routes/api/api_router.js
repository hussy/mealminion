var express = require("express");
var router = express.Router();
var passport = require("passport");

var response = {};
router.post('/', (req, res, next) => {
    response['error']	=	'1';
    response['message']	=	'No API Version Provideddfdf';
    res.end(JSON.stringify(response));
});

router.get('/', (req, res, next) => {
    response['error']	=	'1';
    response['message']	=	'No API Version Provided';
    res.end(JSON.stringify(response));
});

passport.serializeUser(function(userName, done) {
    done(null, userName);
});
  
  passport.deserializeUser(function(userName, done) {
    done(null, userName);
});

module.exports = router;