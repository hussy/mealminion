var express = require("express");
var router = express.Router();
var passport = require("passport");

router.get('/', authenticationMidleware(), async function (req, res) {
    
    if(req.isAuthenticated()){
        res.redirect('/dashboard');
    } else {
        res.redirect('/login');
    }
});
 
router.get('/login', async function (req, res) {
    if(req.isAuthenticated()){
        res.redirect('/dashboard');
    } else {
        res.setHeader('Content-Type','text/html'); 
        var header = new String(read(path.join(__dirname, './views/partials/loginHeader.html')));
        var loginPage = new String(read(path.join(__dirname, './views/login.html')));
        loginPage = header +  loginPage;
        res.end(loginPage);
    }
});

router.get('/dashboard', authenticationMidleware(), async function (req, res) {
    res.redirect('/login');
});

router.get('*', function(req, res){
    res.render('404');
});

passport.serializeUser(function(userName, done) {
    done(null, userName);
});
  
  passport.deserializeUser(function(userName, done) {
    done(null, userName);
});

function authenticationMidleware(){
    return (req,res,next) =>{
        if(req.isAuthenticated()) return next();
        res.redirect('/login');
    }
}

module.exports = router;